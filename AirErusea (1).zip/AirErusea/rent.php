<?php
session_start();
require 'db.php'; // Your database connection

// Ensure the user is logged in
if (!isset($_SESSION['UserID'])) {
    header('Location: index_login.php');
    exit;
}

// Check if the 'DroneID' parameter is passed in the URL
if (isset($_GET['DroneID'])) {
    $DroneID = $_GET['DroneID']; // Use DroneID from the URL
    $UserID = $_SESSION['UserID']; // Get the logged-in user's ID

    // Fetch drone details based on DroneID
    $query = "SELECT * FROM drones WHERE DroneID = :DroneID";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':DroneID', $DroneID);
    $stmt->execute();
    $drone = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the drone exists in the database
    if ($drone) {
        // Handle the rental process when the form is submitted
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Check if the action is to confirm the rental or cancel it
            if (isset($_POST['confirm_rental'])) {
                // Confirm the rental (insert into rentals table)
                $query = "INSERT INTO rentals (UserID, DroneID, RentStart) VALUES (:UserID, :DroneID, NOW())";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':UserID', $UserID);
                $stmt->bindParam(':DroneID', $DroneID);

                if ($stmt->execute()) {
                    echo "Rental successful!";
                } else {
                    echo "Error renting the drone.";
                }
            } elseif (isset($_POST['cancel_rental'])) {
                // Cancel the rental (delete from rentals table)
                $query = "DELETE FROM rentals WHERE UserID = :UserID AND DroneID = :DroneID";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':UserID', $UserID);
                $stmt->bindParam(':DroneID', $DroneID);

                if ($stmt->execute()) {
                    echo "Rental cancelled successfully!";
                } else {
                    echo "Error cancelling the rental.";
                }
            }
        }
    } else {
        echo "Drone not found.";
    }
} else {
    echo "No drone selected.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AirErusea | Rent Drone</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Rent A Drone</h1>
        <div class="header-content">
            <nav class="navbar">
                <a href="dashboard.php">Home</a>
                <a href="drones.php">All Drones</a>
            </nav>
        </div>
    </header>

    <div>
        <?php if ($drone): ?>
            <!-- Display selected drone details -->
            <h2><?php echo htmlspecialchars($drone['Model']); ?></h2>
            <img src="images/<?php echo htmlspecialchars($drone['ImageURL']); ?>" alt="<?php echo htmlspecialchars($drone['Model']); ?>" style="width: 30%; height: auto; object-fit: cover;" />
            <p>Price/Day: $<?php echo htmlspecialchars($drone['PricePerDay']); ?></p>

            <!-- Rental confirmation form -->
            <form method="POST" action="">
                <button type="submit" name="confirm_rental" class="btn btn-primary">Confirm Rental</button>
                <button type="submit" name="cancel_rental" class="btn btn-danger">Cancel Rental</button>
            </form>
        <?php else: ?>
            <p>No drone selected.</p>
        <?php endif; ?>
    </div>
</body>
</html>
