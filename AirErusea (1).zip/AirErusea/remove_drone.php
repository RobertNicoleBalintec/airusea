<?php
require 'auth.php';
requireLogin();
$isAdmin = isAdmin();

if (!$isAdmin) {
    header('Location: dashboard.php');
    exit();
}

require 'db.php';
require 'logger.php';

if (isset($_GET['id'])) {
    $droneId = $_GET['id'];

    $stmt = $pdo->prepare("DELETE FROM drones WHERE DroneID = ?");
    $stmt->execute([$droneId]);

    logAction($_SESSION['user_id'], "Removed drone ID: $droneId");

    header('Location: admin_panel.php');
    exit();
} else {
    echo "Drone ID not specified!";
}
?>
