<?php
require 'auth.php';
requireLogin();
$isAdmin = isAdmin();

if (!$isAdmin) {
    header('Location: dashboard.php');
    exit();
}

require 'db.php';
require 'logger.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $categoryId = $_POST['category_id'];
    $wingTypeId = $_POST['wing_type_id'];
    $pricePerDay = $_POST['price_per_day'];
    $quantityAvailable = $_POST['quantity_available'];

    // Image upload handling (for demo purposes, store it in the images folder)
    $image = $_FILES['image']['name'];
    $targetDir = "images/";
    $targetFile = $targetDir . basename($image);
    move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);

    $stmt = $pdo->prepare("INSERT INTO drones (Brand, Model, CategoryID, WingTypeID, PricePerDay, QuantityAvailable, ImageURL) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$brand, $model, $categoryId, $wingTypeId, $pricePerDay, $quantityAvailable, $image]);

    logAction($_SESSION['user_id'], "Added a new drone: $brand $model");

    header('Location: admin_panel.php');
    exit();
}
?>
